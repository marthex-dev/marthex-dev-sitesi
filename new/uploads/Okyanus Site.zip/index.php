<?php include("menu/header.php");
  $sayfa="Anasayfa";
  ?>
<!--================== WebNetwork ================== -->

        <main>
            <!-- Ana -->
            <section class="third-banner-bg">
                <div class="container custom-container">
                    <div class="row">
                        <div class="col-12">
                            <div class="third-banner-img wow bounceInDown" data-wow-delay=".2s">
                                <img src="img/slider/third_banner_img.png" alt="">
                            </div>
                            <div class="third-banner-content text-center wow bounceInUp" data-wow-delay=".2s">
                                <h2>Okyanus<span> Aılesı</span></h2>
                                <h6>Aramıza hosgeldın!</h6>
                                <a href="basvuru.php" class="btn rotated-btn">SLOT BASVURU</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Ana -->
 <!-- /Başlangıç Sunucu ekleme--							

							
                        </div>

                    </div>

            <!-- Ana alt bölüm -->
            <section class="third-about-area third-about-bg pt-120 pb-90">
                <div class="container custom-container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 order-0 order-lg-2">
                            <div class="third-about-img text-right position-relative">
                                <img src="img/images/third_about_img.png" class="main-img" alt="">
                                <img src="img/images/third_about_img_shadow.png" class="shadow" alt="">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="third-about-content">
                                <div class="third-title-style">
                                    <h2>OKYANUS<span> JAILBREAK</span></h2>
                                    <div class="inner">
                                        <h2>NEDEN EN IYISI OLMAYA CALISIYORUZ?</h2>
                                        <h6 class="vertical-title">okyanus aılesı</h6>
                                        <p>2020 yılından beri "Okyanus Jailbreak" adı altında şan ve şöhret peşinde koşmadan yolumuza devam ediyoruz. 
										Amacımız sıralamaya girmek değil, aynı kafa yapısına sahip olan insanları bir araya getirerek birlikte eğlenmemizdir.</p>
                                    </div>
                                    <a href="#" class="btn rotated-btn">Aramıza Katıl!</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="see-my-info-wrap pt-110">
                        <div class="row">
                            <div class="col-12">
                                <div class="third-section-title text-center mb-75">
                                    <h2>AKTIF <span>JAILBREAK</span> SUNUCUMUZ</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row justify-content-center">
                            <div class="col-xl-4 col-lg-6 col-sm-8">
                                <div class="my-info-box mb-30">
                                    <div class="my-info-box-top">
                                        <h6>Sunucumuz</h6>
                                        <img src="img/bg/my_info_box_hover.png" alt="" class="info-box-top-hover">
                                    </div>
                                    <div class="my-info-box-content">
                                        <div class="my-info-social">
                                            <ul>
                                                <li><a></i>Jailbreak</a></li>
                                                <li><a></i> 34/40 </a></li>
                                                <li><a style="font-size: 12px" href="#"></i> 185.193.165.142</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-6 col-sm-8">
                                <div class="my-info-box mb-30">
                                    <div class="my-info-box-top">
                                        <h6>ARAMIZA KATIL</h6>
                                        <img src="img/bg/my_info_box_hover.png" alt="" class="info-box-top-hover">
                                    </div>
                                    <div class="my-info-box-content">
                                        <div class="my-info-social">
                                            <ul>
                                                <li><a href="https://steamcommunity.com/id/marthex"><i class="fab fa-steam-symbol"></i> STEAM</a></li>
                                                <li><a href="#"><i class="fab fa-discord"></i> Discord</a></li>
                                                <li><a href="#"><i class="fab fa-youtube"></i> Youtube</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-6 col-sm-8">
                                <div class="my-info-box mb-30">
                                    <div class="my-info-box-top">
                                        <h6>STEAM GRUP</h6>
                                        <img src="img/bg/my_info_box_hover.png" alt="" class="info-box-top-hover">
                                    </div>
                                    <div class="my-info-box-content">
                                        <div class="my-clan-wrap">
                                            <div class="clan-logo">
                                                <img src="img/images/clan_logo.png" alt="">
                                            </div>
                                            <div class="my-clan-info">
                                                <h4><span>2317+</span> Üye</h4>
                                                <span>Mevcut Üye Sayısı</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
             <!-- Ana alt bölüm -->

            <!-- Etkinlik-->
            <section class="my-match-area my-match-bg pb-120">
                <div class="container custom-container">
                    <div class="row">
                        <div class="col-12">
                            <div class="third-section-title text-center mb-75">
                                <h2><span>ETKINLIK</span> TABLOMUZ </h2>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="my-match-wrap">
                                <div class="my-match-box-wrap wow fadeInDown" data-wow-delay=".2s">
                                    <img src="img/bg/my_match_box.png" alt="" class="match-box-bg">
                                    <ul>
                                        <li>
                                            <div class="my-match-team">
                                                <div class="team-one">
                                                    <a href="#"><img src="img/team/my_match_clan01.png" alt=""></a>
                                                </div>
                                                <div class="vs">
                                                    <img src="img/team/match_vs02.png" alt="">
                                                </div>
                                                <div class="team-one">
                                                    <a href="#"><img src="img/team/my_match_clan02.png" alt=""></a>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="my-match-info">
                                                <a target="_blank" class="live-btn">PAZARTESİ</a>
                                                <h5>Telli ve Seferioğulları</h5>
                                                <span>SAAT 20.00'DA ETKİNLİK BAŞLİCAKTIR.</span>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="steam://connect/185.193.165.142:27015" target="_blank" class="watch-stream"><i class="fas fa-user-plus"></i> Sunucu Bağlan</a>
                                        </li>
                                    </ul>
                                </div>
								<div class="my-match-box-wrap wow fadeInDown" data-wow-delay=".2s">
                                    <img src="img/bg/my_match_box.png" alt="" class="match-box-bg">
                                    <ul>
                                        <li>
                                            <div class="my-match-team">
                                               
                                                <div class="vs">
                                                    <img src="img/team/policeman.png" alt="">
                                                </div>
                                                <div class="team-one">
                                                    <a href="#"><img src="img/team/money.png" alt=""></a>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="my-match-info">
                                                <a target="_blank" class="live-btn">SALI</a>
                                                <h5>KREDİ ETLİNKİNLİĞİ</h5>
                                                <span>SAAT 20.00'DA ETKİNLİK BAŞLİCAKTIR.</span>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="steam://connect/185.193.165.142:27015" target="_blank" class="watch-stream"><i class="fas fa-user-plus"></i> Sunucu Bağlan</a>
                                        </li>
                                    </ul>
                                </div>
                               
                               
                                
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Etkinlik-->
			
            <!-- brand-area -->
            <div class="brand-area t-brand-bg">
                <div class="container custom-container">
                    <div class="row s-brand-active">
                       
                        <div class="col-12">
                            <div class="t-brand-item">
                                <img src="img/brand/t_brand_logo02.png" alt="">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="t-brand-item">
                                <img src="img/brand/t_brand_logo03.png" alt="">
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="t-brand-item">
                                <img src="img/brand/t_brand_logo05.png" alt="">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="t-brand-item">
                                <img src="img/brand/t_brand_logo03.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- brand-area-end -->

        </main>
        <!-- main-area-end -->
<!--================== WebNetwork ================== -->
<?php include("menu/footer.php"); ?>
<!--================== WebNetwork ================== -->