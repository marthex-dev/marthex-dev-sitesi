 
 <?php include("menu/header.php");
  $sayfa="LR Kuralları";
  ?>
<!--==================header - Okyanus================== -->
 
           
 
 <!-- game-single-area -->
            <section class="game-single-area pt-120 pb-180">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="game-single-content game-overview-content">
                                <div class="upcoming-game-head">
                                    <div class="uc-game-head-title">
                                        <h4>LR <span>KURALLARI</span></h4>
                                    </div>
                                </div>
                                <ul class="blog-details-list">
<li>Sadece atan kişi eğilebilir.</li>
<li>Sadece lr ile korumaya geçilir.</li>
<li>2 body infaz</li>
<li>Çıldırmak yasak.</li>
<li>Yüz yüze bakılmaması infaz sebebidir.</li>
<li>Kandırmak yasaktır.</li>
<li>Koruma herhangi bir kurala uymazsa T'ye atılır ve karşısındaki kişi korumaya geçer. </li>
                                </ul>	
<!-- TEHDİT -->
							
							
							
            <div class="blog-list-post blog-details-wrap">
                                <div class="blog-list-post-content">
                                   
                                    
    
                                    <blockquote>
                                        “ Yetkili ve oyuncular kurallara uymak zorundadır. Kurallara umayan arkadaşlar <a href="ceza-sistemi.php">ceza</a> süresine göre ceza yicektir.”
                                    </blockquote>
                                   
                                </div>
             </div>
			<!-- TEHDİT --> 								
                            </div>
                        </div>
                    </div>
			    </div>
            </section>
          
                                         
                        
			
			
<!--==================footer - Okyanus================== -->
             <?php include("menu/footer.php"); ?>