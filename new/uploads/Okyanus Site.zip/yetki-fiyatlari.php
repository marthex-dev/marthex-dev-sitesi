
 <?php include("menu/header.php");
  $sayfa="Yetki";
  ?>
<!--==================header - Okyanus================== -->
        <!-- main-area -->
        <main>

            <!-- shop-area -->
            <section class="shop-area pt-120 pb-90">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-sm-6">
                            <div class="accessories-item text-center mb-80">
                                <div class="accessories-thumb mb-30">
                                    <img src="img/product/shop_item05.jpg" alt=""></a>
                                </div>
                                <div class="accessories-content">
                                    <h5><a>Moderatör</a></h5>
                                    <span>38,99 TL</span>
                                    <a href="siparis.php" class="shop-add-action">BAĞIŞLA!</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="accessories-item text-center mb-80">
                                <div class="accessories-thumb mb-30">
                                    <img src="img/product/shop_item06.jpg" alt=""></a>
                                </div>
                                <div class="accessories-content">
                                    <h5><a>Rehber</a></h5>
                                    <span>49,99 TL</span>
                                    <a href="siparis.php" class="shop-add-action">BAĞIŞLA!</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="accessories-item text-center mb-80">
                                <div class="accessories-thumb mb-30">
                                   <img src="img/product/shop_item07.jpg" alt=""></a>
                                </div>
                                <div class="accessories-content">
                                    <h5><a>Kaptan</a></h5>
                                    <span>97,99 TL</span>
                                    <a href="sipais.php" class="shop-add-action">BAĞIŞLA!</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="accessories-item text-center mb-80">
                                <div class="accessories-thumb mb-30">
                                    <img src="img/product/shop_item08.jpg" alt=""></a>
                                </div>
                                <div class="accessories-content">
                                    <h5><a>Premium</a></h5>
                                    <span>100,99 TL</span>
                                    <a href="siparis.php" class="shop-add-action">BAĞIŞLA!</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="accessories-item text-center mb-80">
                                <div class="accessories-thumb mb-30">
                                   <img src="img/product/shop_item09.jpg" alt=""></a>
                                </div>
                                <div class="accessories-content">
                                    <h5><a>Sunucu Yardımcısı</a></h5>
                                    <span>148,99 TL</span>
                                    <a href="siparis.php" class="shop-add-action">BAĞIŞLA!<a>
                                </div>
                            </div>
                        </div>
						<div class="col-lg-4 col-sm-6">
                            <div class="accessories-item text-center mb-80">
                                <div class="accessories-thumb mb-30">
                                   <img src="img/product/shop_item10.jpg" alt=""></a>
                                </div>
                                <div class="accessories-content">
                                    <h5><a>Ortak</a></h5>
                                    <span>398,99 TL</span>
                                    <a href="siparis.php" class="shop-add-action">BAĞIŞLA!</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- shop-area-end -->
			
 <section class="latest-match-area latest-match-bg pt-115 pb-90">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-8">
                        <div class="section-title title-style-three white-title text-center mb-70">
                            <h2><span>Desteğe mi ihtiyacınız var?</span></h2>
                            <p>Her türlü sorunlarınızı <a href="https://discord.gg/okyanus">discord</a> sunucumuzdan çözebilirsiniz.</p>
                        </div>
                    </div>
                
                    
                            </div>
            </div>
                    </div>
                </div>
            </div>
        </section>
		
		
		 <!-- game-single-area -->
            <section class="game-single-area pt-120 pb-180">
               
            </section>
			
			<!-- main-area-end -->
		
        </main>
        <!-- main-area-end -->

        <?php include("menu/footer.php"); ?>
<!--==================footer - Okyanus================== -->