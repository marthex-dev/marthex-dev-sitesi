 
 <?php include("menu/header.php");
  $sayfa="Komutçu Kuralları";
  ?>
<!--==================header - Okyanus================== -->
 
           
 
 <!-- Kurallara Başlangıç -->
            <section class="game-single-area pt-120 pb-180">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="game-single-content game-overview-content">
                                
                               

                                <div class="upcoming-game-head">
                                    <div class="uc-game-head-title">
                                        <h4>KOMUTÇU <span>KURALLARI</span></h4>
                                    </div>
                                </div>
                                <ul class="blog-details-list">
<li>Korumalar 7-14-21-28-35 şeklinde alınır.</li>
<li>İlk af zorunludur.</li>
<li>Hücre kapısı 56.30'a kadar açılmalıdır.</li>
<li>Komutçu isyan varken af verilirse isyan sayılır. Af veremez veya komut kullanamaz. Hücrede silah olması isyandan sayılmaz.</li>
<li>Komutçu admin komutçudan farklı birisi seçilir ve seçilen komutçu admin dışı herhangi birinin komut yazması kesinlikle yasaktır.</li>
<li>Kapı açılmadan oyun oynatılması yasaktır.</li>
<li>Hücre kapısı açıldığında hpt verilmesi zorunludur.</li>
<li>İsyan eli haricindeki tüm ellerde hem T hem CT Rush zorunludur.</li>
<li>Komut verilmeden hücre içerisine veya kaçak kapısına ateş edilemez. Edildiği takdirde slayct atılır ve bu el isyandan sayılır.</li>
<li>God elli oyun 3 elde bir oynatılabilir. Sebepsiz bir şekilde birini vurmak yasaktır.</li>
<li>Komutçu değiş kal oylaması 40 dakikada bir otomatik olarak yapılır.</li>
<li>İsyan ellerinde 58.15’te CT İnfo verilmesi gerekmektedir.</li>
<li>Silah odasında CT ve ya T can doldurma noktalarında durup birbirine ve ya birine ateş açması artık <strong>serbesttir.</strong></li>
<li>Özel CT silahları yalnızca Terörist takımı en az 20 kişiyken serbesttir. Terörist takımı 20 kişi üzerindeyse tüm CT takımı özel silah alabilir.</li>
<li>Başkasının yerine koruma olarak geçen oyuncu, isyanı yerine geçtiği kişinin isyanı ile aynı olur.</li>
<li>Sunucumuzda skin takibi yasaktır. Godlu ellerde komutçu isterse skin takibi yapabilir.</li>
<li>İsyan ellerinde LR odasına gitmek yasaktır.</li>
<li>Fantazi FF yasaktır. Oyuncuları dar yerlere çekmemeye çalışın.</li>
<li>Küfürü eğlence amaçlı kullanılabilir ama abartılmadan. Abartılırsa yetkililer tarafından uyarılır ve ya ceza uygulanır.</li>
<li>İsyan eli başlamadan önce sadece Komutçu hook basabilir.</li>
                                </ul>              

                             
<!-- TEHDİT -->
							
							
							
            <div class="blog-list-post blog-details-wrap">
                                <div class="blog-list-post-content">
                                   
                                    
    
                                    <blockquote>
                                        “ Yetkili ve oyuncular kurallara uymak zorundadır. Kurallara umayan arkadaşlar <a href="ceza-sistemi.php">ceza</a> süresine göre ceza yicektir.”
                                    </blockquote>
                                   
                                </div>
             </div>
			<!-- TEHDİT --> 								
                            </div>
                        </div>
                    </div>
			    </div>
            </section>
          
<!-- Kurallara Bitiş -->                            
                        
			
			
<!--==================footer - Okyanus================== -->
             <?php include("menu/footer.php"); ?>