 
 <?php include("menu/header.php");
  $sayfa="Ceza Sistemi";
  ?>
<!--==================header - Okyanus================== -->


            <!-- game-single-area -->
            <section class="game-single-area pt-120 pb-120">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="game-single-content">

                                <div class="game-single-title mt-60 mb-30">
                                    <h4>Ceza Süreleri</h4>
							    <div class="upcoming-game-head">
                                    <div class="uc-game-head-title">
                                        <span>Oyunculara bu cezalar verilir.</span>
                                    </div>
                                </div>
                                </div>
                                <div class="game-single-info mb-65">
                                    <ul>
                                        <li><span>Caps Lock / Flood - Spam:</span>İlk seferinde uyarı devam ederse 10 dakika gag atılır.</li>
                                      <li><span>Şahsi Hakaret / Hakaret:</span>İlk seferinde uyarı devam ederse 10 dakika gag uygulanır.</li>
                                      <li><span>Genel Küfür / Hakaret:</span>20 dakika gag atılır.</li>
                                      <li><span>Ailevi / Irki Küfür:</span>İlk seferinde 120 dakika gag devam ederse süresiz gag atılır.</li>
                                      <li><span>Sunucuyu trollemek:</span> Uyarılır devam ederse yetkilinin insiyafitine göre cezai işlem uygulanabilir. </li>
                                      <li><span>Dini Küfür / Reklam:</span>Sınırsız gag atılır.</li>
                                      <li><span>İnfo:</span>Uyarılır devam ederse 10 dakika gag atılır.</li>
                                    </ul>
                                </div>
                            </div>
							<div class="game-single-content">
                               
                                <div class="game-single-title mt-60 mb-30">
                                    <h4><span>Yetkili</span> Ceza Süreleri</h4>
							    <div class="upcoming-game-head">
                                    <div class="uc-game-head-title">
                                        <span>Yetkili oyunculara bu cezalardan verilir.</span>
                                    </div>
                                </div>
                                </div>
                                <div class="game-single-info mb-65">
                                    <ul>
                                      <li><span>Caps Lock / Flood - Spam:</span>İlk seferinde 5 dakika gag devam ederse 15 dakika gag atılır.</li>
                                      <li><span>Şahsi Küfür / Hakaret:</span>İlk seferinde 15 dakika gag devam ederse 30 dk gag atılır.</li>
                                      <li><span>Genel Küfür / Hakaret:</span>30 dakika gag atılır.</li>
                                      <li><span>Ailevi / Irki Küfür:</span>İlk seferinde 120 dakika gag devam ederse yetkisi alınır.</li>
                                      <li><span>Sunucuyu trollemek:</span>Uyarılır devam ederse yetkilinin insiyafitine göre cezai işlem uygulanabilir.</li>
                                      <li><span>Dini Küfür / Reklam:</span>Sınırsız gag atılır ve yetkisi alınır.</li>
                                      <li><span>İnfo:</span>İlk seferinde uyarılır devam ederse 15 dakika gag atılır.</li>
                                    </ul>
                                </div>
                                <div class="game-single-title mb-30">
                                    <h4>NEDEN <span>CEZA</span> VERİLİYOR?</h4>
                                </div>
                                <p>Sunucu içerisinde ki dostluk ve huzuru korumak amacıyla bu cezalar uygulanmaktadır. Sunucumuzda oynayan tüm oyuncular bu kurallara dahil olmak üzere
								aynı cezayı alır.</p>
                                 <div class="game-single-title mb-30">
                                    <h4><span>YENİ</span> GELEN <span>OYUNCU</span> KURAL İHLALİ YAPTIYSA NE YAPMALIYIM? </h4>
									<p>Yeni gelen bir oyuncu kural ihlalı yaptıysa önce oyuncuyu uyarmalıyız, yaptığı eylemin kural dışı olduğunu ve bunun sunucuda yasak olduğunu belirtmemiz gerekmektedir. İkinci bir hareketinde yine
									aynı eylemi yapıyorsa ceza sistemine göre cezasını veriniz.</p>
                                </div>   
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- game-single-area-end -->

            

        <!--==================footer - Okyanus================== -->
             <?php include("menu/footer.php"); ?>