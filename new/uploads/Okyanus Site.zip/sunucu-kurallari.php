 
 <?php include("menu/header.php");
  $sayfa="Sunucu Kuralları";
  ?>
<!--==================header - Okyanus================== -->
 
           
 
 <!-- game-single-area -->
            <section class="game-single-area pt-120 pb-180">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="game-single-content game-overview-content">
                                <div class="upcoming-game-head">
                                    <div class="uc-game-head-title">
                                        <span>KURALLARA UYULMASI ZORUNLUDUR.</span>
                                        <h4>GENEL/SUNUCU <span>KURALLARI</span></h4>
                                    </div>
                                </div>
                                <ul class="blog-details-list">
<li>Sunucumuz da küfür, argo, ırkçılık, din veya siyaset yasaktır.</li>
<li>Sunucu içerisinde hile veya herhangi bir 3. parti program kullanmak sınırsız ban sebebidir.</li>
<li>Vac ban yerseniz eski hesabınızdaki market veya kredi kesinlikle verilmez.</li>
<li>Yetkili olan herkesin Discord sunucumuza katılımı zorunludur.</li>
<li>Gereksiz Hakgg ,af, kom dk gibi yazılar yazan kısacası komutçuyu toxic olan arkadaşlara gag atılır.</li>
<li>Sunucuyu ve komudu trollemek yasaktır. Yapanlara <a href="ceza.php">ceza süresine</a> göre ceza uygulanır. </li>
<li>Ölü durumda iken info verilmesi yasaktır. Yaşayanlar/ölü olmayanlar istediği gibi info verebilir.</li>
<li>Sunucu içerisinde yapılan herhangi bir oylamaya karışmak yasaktır.</li>
<li>Korumalar haksalma işlemini <strong>!haksal</strong> komuduyla yapmak zorundadır.</li>
<li>Oynanan tüm oyunlarda sunucunun herhangi bir açığını kullanmak, oyunlarda herhangi bir parkurda kısayol ve admin komutları yasaktır. Kısayol komutçular izin verdiği sürece yapılabilir.</li>
<li>Saklambaç ve deagle sustum gibi uzun süren oyunlar sunucu 20 kişi üstündeyse oynatılması yasaktır.</li>
<li>Sunucumuzda skin takibi yasaktır. Godlu ellerde serbesttir.</li>
<li>Küçük modellerin eğilme zorunluluğu yoktur. İsterse shift basabilirler.</li>
<li>İsyan ellerinde son süre <strong>53:00</strong>'dır. T bu 53:00'a kadar isyan atmazsa, T takımına slay atılır. İsyan sıfırlanır. </li>
<li>Normal ellerde dahil T takımı portallarda en fazla <strong>3 dakika</strong> durabilir.</li>
<li>Sunucumuzda kişiyi tahrik edecek ez, ezik, kolay, basit vb derecede yazılar yazmak yasaktır. Kişi rahatsız olursa ceza uygulanır.</li>
<li>Büyükisyan haritalarında 55.00'dan sonra sadece isyan ellerinde portallarda bulunma infazı vardır. Her iki takım içinde geçerlidir.</li>
<li>İsyan ellerinde Terörist takımının son rush süresi 56:30'dır ve korumaların isyan ellerinde exkz can bölgesi üstüne çıkması yasaktır.</li>
<li>Sunucuyu bölmeye çalışmak, üyeleri başka sunuculara davet etmek ve Okyanus Oyuncu Topluluğu içinde başka bir oluşum oluşturmaya çalışmak yasaktır.</li>
<li>Kural açıkları arayıp bu açıklardan faydalanmak yasaktır.</li>
<li>Komutçu veya korumanın ölmesi durumunda, dışarıda hala bulunan bir kaçak varsa ve af verilirse o el isyan yapılmış sayılır.</li>
<li>Destek almak istediğiniz herhangi bir konu olursa <a href="https://discord.gg/C3pfJK2dg6">#destek</a> kanalına yazabilirsiniz.</li>
                                </ul>   

                            
<!-- TEHDİT -->
							
							
							
            <div class="blog-list-post blog-details-wrap">
                                <div class="blog-list-post-content">
                                   
                                    
    
                                    <blockquote>
                                        “ Yetkili ve oyuncular kurallara uymak zorundadır. Kurallara umayan arkadaşlar <a href="ceza-sistemi.php">ceza</a> süresine göre ceza yicektir.”
                                    </blockquote>
                                   
                                </div>
             </div>
			<!-- TEHDİT --> 								
                            </div>
                        </div>
                    </div>
			    </div>
            </section>
          
                                         
                        
			
			
<!--==================footer - Okyanus================== -->
             <?php include("menu/footer.php"); ?>