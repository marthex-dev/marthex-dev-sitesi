<?php include("menu/header.php");
  $sayfa="Ekibimiz";
  ?>
<!--==================header - Okyanus================== -->
       
        <main>

            
        
		
            <!-- game-single-area-end -->
        <section class="team-member-area pt-115 pb-125">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-8">
                        <div class="section-title title-style-three text-center mb-70">
                            <h2><span>OKYANUS</span></h2>
                            <h2>Yönetim Kadrosu<span></span></h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="team-member-box text-center mb-50">
                            <div class="team-member-thumb">
                                <img src="img/team/team_member01.jpg" alt="">
                                <div class="team-member-social">
                                    <ul>
                                        <li><a href="https://steamcommunity.com/id/merseh/"><i class="fab fa-steam"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="team-member-content">
                                <h4><a href="#">merséh</a></h4>
                                <span>Kurucu</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="team-member-box text-center mb-50">
                            <div class="team-member-thumb">
                                <img src="img/team/team_member02.jpg" alt="">
                                <div class="team-member-social">
                                    <ul>
                                        <li><a href="https://steamcommunity.com/id/marthex/"><i class="fab fa-steam"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="team-member-content">
                                <h4><a href="#">Marthex</a></h4>
                                <span>Kurucu</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="team-member-box text-center mb-50">
                            <div class="team-member-thumb">
                                <img src="img/team/team_member03.jpg" alt="">
                                <div class="team-member-social">
                                    <ul>
                                        <li><a href="https://steamcommunity.com/id/efedeniz/"><i class="fab fa-steam"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="team-member-content">
                                <h4><a href="#">EfeDeniz</a></h4>
                                <span>Kurucu</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="team-member-box text-center mb-50">
                            <div class="team-member-thumb">
                                <img src="img/team/team_member04.jpg" alt="">
                                <div class="team-member-social">
                                    <ul>
                                    
                                    </ul>
                                </div>
                            </div>
                            <div class="team-member-content">
                                <h4><a href="#">Ugur</a></h4>
                                <span>Yönetici</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
		<section class="latest-match-area latest-match-bg pt-115 pb-90">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-8">
                        <div class="section-title title-style-three white-title text-center mb-70">
                            <h2><span>Desteğe mi ihtiyacınız var?</span></h2>
                            <p>Her türlü sorunlarınızı <a href="https://discord.gg/okyanus">discord</a> sunucumuzdan çözebilirsiniz.</p>
                        </div>
                    </div>
                
                    
                            </div>
            </div>
                    </div>
                </div>
            </div>
        </section>
         </main>
        <?php include("menu/footer.php"); ?>
<!--==================footer - Okyanus================== -->
               