document.addEventListener('DOMContentLoaded', function () {
    const imageCards = document.querySelectorAll('.image-card');
    imageCards.forEach(function (card) {
        const description = card.getAttribute('data-description');
        const price = card.getAttribute('data-price');
        const infoContainer = document.createElement('div');
        infoContainer.classList.add('image-info');
        infoContainer.innerHTML = `
            <p>${description}</p>
            <p>Fiyat: ${price} TL</p>
            <button style="background-color: #5e7351; color: white;">Sipariş Ver</button>
        `;
        card.appendChild(infoContainer);
    });
});
