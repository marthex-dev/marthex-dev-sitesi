<?php

$RabiwebBuild = "1.0";
$RabiwebVersion = "327";