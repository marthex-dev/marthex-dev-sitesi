<?php

require $realPath . '/index.php';