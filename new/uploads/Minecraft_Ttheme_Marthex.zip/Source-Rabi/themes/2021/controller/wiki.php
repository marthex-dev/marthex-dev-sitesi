<?php

require $realPath . '/view/wiki.php';