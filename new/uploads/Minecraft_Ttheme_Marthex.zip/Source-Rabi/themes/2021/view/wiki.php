<?php 

$newURL = "https://wiki.rabi.web.tr";
header('Location: '.$newURL);

?>