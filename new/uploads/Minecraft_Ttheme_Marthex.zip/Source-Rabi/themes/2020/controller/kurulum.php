<?php


require $realPath . '/view/install.php';