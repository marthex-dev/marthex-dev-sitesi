<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Discord - Marthex</title>
  <link rel="stylesheet" href="./style.css">
  <link rel="stylesheet" href="./reis.css">
  <link rel="stylesheet" href="./uye.css">
</head>
<body>
<main class="container">
  <aside class="servers">
    <div class="servers-collection">
      <div class="server focusable server-friends unread" role="button" aria-label="Friends unread">
        <div class="server-icon"><svg><use xlink:href="#icon-friends" /></svg></div>
      </div>
    </div>
    <div class="servers-collection">
      <div class="server focusable active" role="button" aria-label="My Server" aria-selected="true">
        <div class="server-icon"><img src="https://cdn.discordapp.com/icons/1066472195536212038/5944fd4bcfdcc03f9b9ac63c2b79d1b8.webp" /></div>
      </div>
    </div>
  </aside>
  <aside class="channels">
    <header class="channels-header focusable">
      <h3 role="header" class="channels-header-name">Marthex.dev</h3>
      <svg role="button" aria-label="Dropdown" class="channels-header-dropdown"><use xlink:href="#icon-dropdown" /></svg>
    </header>
    <?php
    // Discord API ayarları
    $token = "#";
    $guildID = "#";

    function requestDiscordAPI($path) {
        global $token;

        $url = "https://discord.com/api/v10" . $path;
        $headers = [
            "Authorization: Bot " . $token,
            "Content-Type: application/json"
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response, true);
    }

    function getDiscordChannels() {
        global $guildID;

        $guildPath = "/guilds/{$guildID}";
        $channelsPath = "{$guildPath}/channels";

        $guildResponse = requestDiscordAPI($guildPath);
        $channelsResponse = requestDiscordAPI($channelsPath);

        $categories = [];

        foreach ($channelsResponse as $channel) {
            if ($channel["type"] === 4) {
                $categoryID = $channel["id"];
                $categories[$categoryID] = [
                    "category" => $channel["name"],
                    "channels" => []
                ];
            } elseif ($channel["type"] === 0) {
                $categoryID = $channel["parent_id"];

                if (isset($categories[$categoryID])) {
                    $categories[$categoryID]["channels"][] = [
                        "name" => $channel["name"],
                        "invite" => "#",
                        "settings" => "#"
                    ];
                }
            }
        }

        return $categories;
    }

    // Kanalları görüntüleme
    $channels = getDiscordChannels();

    echo '<section class="channels-list">';

    foreach ($channels as $category) {
        echo '<header class="channels-list-header focusable">';
        echo '<h5>' . $category['category'] . '</h5>';
        echo '</header>';
        echo '<ul class="channels-list-text">';

        foreach ($category['channels'] as $channel) {
            echo '<li class="channel focusable channel-text active">';
            echo '<span class="channel-name">' . $channel['name'] . '</span>';
            echo '<button class="button" role="button" aria-label="Invite"><svg><use xlink:href="#icon-invite" /></svg></button>';
            echo '<button class="button" role="button" aria-label="settings"><svg><use xlink:href="#icon-channel-settings" /></svg></button>';
            echo '</li>';
        }

        echo '</ul>';
    }

    echo '</section>';
    ?>
    <footer class="channels-footer">
      <img class="avatar" alt="Avatar" src="https://cdn.discordapp.com/avatars/293787178784391168/a_4be41027e2584c18df4e8af7d6a317cf.png" />
      <div class="channels-footer-details">
        <span class="username">Marthex</span>
        <span class="tag">#9703</span>
      </div>
      <div class="channels-footer-controls button-group">
        <button role="button" aria-label="Mute" class="button button-mute"><svg><use xlink:href="#icon-mute" /></svg></button>
        <button role="button" aria-label="Deafen" class="button button-deafen"><svg><use xlink:href="#icon-deafen" /></svg></button>
        <button role="button" aria-label="Settings" class="button button-settings"><svg><use xlink:href="#icon-settings" /></svg></button>
      </div>
    </footer>
  </aside>
  <div class="vert-container">
    <menu type="toolbar" class="menu">
      <h2 class="menu-name">📘・projeler</h2>
    </menu>
    <section class="chat">
    <?php
    // Discord bot tokenınızı girin
    $botToken = "ODk4NTA0OTEwODU1ODg0ODQw.GUwEw8.xL23XePQTV4FS62ZX_cVoYkonf29wj3FAVUbhQ";

    // Discord kanalından mesajları alacak fonksiyon
    function getDiscordMessages($channelID, $limit = 30) {
        global $botToken;

        $url = "https://discord.com/api/channels/{$channelID}/messages?limit={$limit}";

        $headers = array(
            "Authorization: Bot {$botToken}"
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        $messages = json_decode($response, true);
        return $messages;
    }

    // Discord kullanıcının profil fotoğrafını alacak fonksiyon
    function getUserAvatar($userID, $avatarHash) {
        return "https://cdn.discordapp.com/avatars/{$userID}/{$avatarHash}.png";
    }

    // Discord mesajlarını ve kullanıcı bilgilerini al
    $channelID = "1077954463257596014";
    $messages = getDiscordMessages($channelID);

    // Mesajları tarih sırasına göre sıralayın (en eski mesaj en üstte olacak şekilde)
    usort($messages, function($a, $b) {
        return strtotime($a['timestamp']) - strtotime($b['timestamp']);
    });

    // Mesajları ve kullanıcı bilgilerini web sitenizde göster
    foreach ($messages as $message) {
        // Eğer mesaj bot tarafından atıldıysa veya sisteme kayıtlı bir kullanıcı değilse, atlat
        if (isset($message['author']['bot']) || !isset($message['author']['username'])) {
            continue;
        }

        $content = $message['content'];
        $username = $message['author']['username'];
        $avatarHash = $message['author']['avatar'];
        $userID = $message['author']['id'];
        $avatarURL = getUserAvatar($userID, $avatarHash);
        $timestamp = date('h:i A', strtotime($message['timestamp']));

        echo "<div class='message'>";
        echo "<img class='avatar' alt='Kullanıcı Avatar' src='{$avatarURL}'>";
        echo "<div class='message-content'>";
        echo "<span class='username'>{$username}</span>";
        echo "<span class='timestamp'>{$timestamp}</span>";
        echo "<p>{$content}</p>";

        // Eğer mesajda resim veya dosya varsa, onları da görüntüle
        if (isset($message['attachments'])) {
            foreach ($message['attachments'] as $attachment) {
                $attachmentURL = $attachment['url'];
                $attachmentFilename = $attachment['filename'];

                // Sadece resimleri görüntüle
                if (strpos($attachment['content_type'], 'image') !== false) {
                    echo "<img class='message-image' src='{$attachmentURL}' alt='Resim' style='max-width: 500px;'>";
                } else {
                    echo "<a href='{$attachmentURL}' download='{$attachmentFilename}' class='attachment-link'>{$attachmentFilename}</a>";
                }
            }
        }

        echo "</div>";
        echo "</div>";
    }
    ?>
    </section>
  </div>
</main>
</body>
</html>
