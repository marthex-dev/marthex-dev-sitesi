const userId = '293787178784391168'; 

const socket = new WebSocket('wss://api.lanyard.rest/socket');

socket.addEventListener('open', () => {
    socket.send(JSON.stringify({
        op: 2,
        d: {
            subscribe_to_ids: [userId]
        }
    }));
});

socket.addEventListener('message', (event) => {
    const data = JSON.parse(event.data);

    if (data.t === 'INIT_STATE' || data.t === 'PRESENCE_UPDATE') {
        const presence = data.d[userId];
        const statusText = document.getElementById('discord-status-text');
        const avatar = document.getElementById('discord-avatar');
        const spotifyActivity = document.getElementById('spotify-activity');

        const spotifyData = presence.activities.find(act => act.type === 2);
        if (spotifyData) {
            const coverImage = spotifyData.assets.largeImageURL ?? ''; // 
            spotifyActivity.innerHTML = `
                <p>
                    <img src="https://cdn.discordapp.com/attachments/1114639600909029516/1251109329403117619/Spotify_icon.png?ex=666d61dc&is=666c105c&hm=442c335953f9caa81efbf2522d86fe1381cc1cde8deddfe095812573b3694250&" alt="Spotify Icon" style="width: 20px; height: 20px;">
                    ${spotifyData.details} - ${spotifyData.state} 
                </p>`;
        } else {
            spotifyActivity.innerHTML = '';
        }
        
        

        if (presence.discord_user) {
            avatar.src = `https://cdn.discordapp.com/avatars/${presence.discord_user.id}/${presence.discord_user.avatar}.png`;
            document.getElementById('discord-username').textContent = presence.discord_user.username;
        }
        if (presence.discord_status) {
            let status = '';
            switch (presence.discord_status) {
                case 'online':
                    status = 'Aktif';
                    break;
                case 'idle':
                    status = 'Boşta';
                    break;
                case 'dnd':
                    status = 'Rahatsız Etmeyin';
                    break;
                default:
                    status = 'Bilinmiyor';
            }
            statusText.textContent = `Status: ${status}`;
            statusText.classList.add(presence.discord_status); 
        }
        
    }
});

document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});