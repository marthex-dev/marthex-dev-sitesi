<?php
/*
https://www.r10.net/profil/45043-brown.html
bu script ücretsiz dağıtılmaktadır.
kullanılan temanın lisansını envato üzerinden satın alabilirsiniz.
*/
include('inc/config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- META INFO -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <!-- PAGE TITLE -->
    <title><?php echo ayar('site_title'); ?></title>

    <!-- META KEYWORDS AND DESCRIPTION -->
    <meta name="description" content="<?php echo ayar('site_description'); ?>">
    <meta name="keywords" content="<?php echo ayar('site_keywords'); ?>" />

    <!-- META VIEW PORT -->
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, shrink-to-fit=no">

    <link rel="shortcut icon" href="<?php echo ayar('site_favicon'); ?>">

    <!-- WEB FONT-FAMILY -->
    <link href="https://fonts.googleapis.com/css?family=Libre+Baskerville:400,400i,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">

    <!-- VENDOR FONT ICONS CSS -->
    <link rel="stylesheet" href="fonticons/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="fonticons/et-line/et-line-font.css">
    <link rel="stylesheet" href="fonticons/material-webfont/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="fonticons/pixeden/pe-icon-7-stroke.css">
    <link rel="stylesheet" href="fonticons/simplelineicons/css/simple-line-icons.css">

    <!-- COMMON VENDOR CSS -->
    <link rel="stylesheet" href="vendor/animate-css/animate.min.css">
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/sweetalert/sweetalert2.min.css">
    <link rel="stylesheet" href="vendor/jarallax/jarallax.css">
    <link rel="stylesheet" href="vendor/owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css">
    
    <!-- PAGE SPECIFIC VENDOR CSS -->

    <!-- TEMPLATE COMMON CSS -->
    <link rel="stylesheet" href="css/ckav-main.css">
    <link rel="stylesheet" href="css/ckav-elements.css">
    <link rel="stylesheet" href="css/ckav-helper.css">
    <link rel="stylesheet" href="css/ckav-responsive.css">

    <!-- DEMO SPECIFIC TEMPLATE CSS -->

    <!-- TEMPLATE THEME CSS -->

    <!-- TEMPLATE USER CUSTOM CSS -->
    <link rel="stylesheet" href="css/template-custom.css">
</head>

<body class="ckav-body tooltip-light">

    <!--
    ************************************************************
    * PAGE LOADER
    *************************************************************
    -->
    <div id="loader">
        <div class="load-three-bounce">
            <div class="load-child bounce1"></div>
            <div class="load-child bounce2"></div>
            <div class="load-child bounce3"></div>
        </div>
    </div>
    <!-- ************** END : PAGE LOADER **************  -->


    <div class="ckav-body">
        
        <!--
        ************************************************************
        * HEADER
        *************************************************************
        -->
        <header class="ckav-header-area" data-ckav-smd="padding-t-0">
            <div class="inner-wrapper">
                <div class="container-fluid padding-0">
                    <div class="row align-items-center">

                        <!-- LOGO -->
                        <div class="col-2">
                            <a href="index.php" class="logo-wrapper width-px-80" data-ckav-smd="margin-t-10 margin-l-10 margin-b-10 width-px-60">
                                <img src="<?php echo ayar('site_logo'); ?>" alt="<?php echo ayar('site_title'); ?>">
                            </a>
                        </div>

                        <!-- NAVIGATION -->
                        <div class="col-10 flex-cr">

                            <!-- MENU ICON -->
                            <div class="menu-icon-wrp display-none" data-ckav-smd="display-flex margin-r-10">
                                <div class="menu-icon">
                                    <div class="bar"></div>
                                </div>
                            </div>
                            
                            <div class="navigation-wrapper align-right" data-ckav-smd="align-center">
                                <ul class="navigation-ul">
                                    
                                    <li class="navigation-li">
                                        <a href="#home" class="navigation-a" data-page-type="main-page">Anasayfa</a>    
                                    </li>
                                    
                                    <li class="navigation-li">
                                        <a href="#about" class="navigation-a" data-page-type="inner-page">Hakkımda</a>    
                                    </li>

                                    <li class="navigation-li">
                                        <a href="#services" class="navigation-a" data-page-type="inner-page">Hizmetlerim</a>    
                                    </li>

                                    <li class="navigation-li">
                                        <a href="#portfolio" class="navigation-a" data-page-type="inner-page">Portfolyo</a>    
                                    </li>

                                    <li class="navigation-li">
                                        <a href="#testimonials" class="navigation-a" data-page-type="inner-page">Ne Dediler?</a>    
                                    </li>

                                    <li class="navigation-li">
                                        <a href="#contact" class="navigation-a" data-page-type="inner-page">İletişim</a>    
                                    </li>

                                </ul>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </header>
        <!-- ************** END : HEADER **************  -->
        
        <!--
        ************************************************************
        * HOME PAGE
        *************************************************************
        -->
        <div class="ckav-home-area main-page flex-bc padding-b-medium">

            <!-- PARTICLE EFFECT -->
            <div class="full-wh full-wh zindex-1">
                <div class="height-100" id="particles-js"></div>
            </div>

            <div class="container zindex-2 align-center">

                <!-- INTRO TEXT -->
                <div class="intro-text width-70 margin-auto typo-light" data-ckav-smd="width-100 align-center">
                    <h2 class="heading xlarge bold-800" data-ckav-smd="large"><?php echo ayar('homepage_01'); ?></h2>
                    <p class="heading-sub small bold-400 margin-b-0" data-ckav-smd="mini margin-b-40"><?php echo ayar('homepage_02'); ?></p>
                </div>

            </div>

            <!--=================================
            = BACKGROUND HOLDER
            ==================================-->
            <div class="bg-holder zindex-0">
                
                <!-- OVERLAY -->
                <b data-bgholder="overlay" class="full-wh zindex-2" data-linear-gradient="rgba(1,149,251,0)|rgba(0, 0, 0, 0.6)"></b>
                
                <!-- BACKGROUND IMAGE -->
                <b data-bgholder="background-image" class="full-wh bg-cover bg-cc zindex-1" data-bg-image="<?php echo ayar('homepage_image'); ?>"></b>
                
            </div>
            <!-- ======= END : BACKGROUND HOLDER =======  -->
        </div>
        <!-- ************** END : HOME PAGE **************  -->

        <!--
        ************************************************************
        * SUB PAGES
        *************************************************************
        -->
        <div class="ckav-page-area" data-linear-gradient="rgba(1,149,251,0.8)|rgba(179, 217, 254, 0.3)">

            <!--=================================
            = ABOUT
            ==================================-->
            <div id="about" class="about-page page-wrapper">
                <div class="inner-wrapper">
                    <!-- PAGE HEADER -->
                    <div class="page-header-area bgcolor-default typo-light padding-t-40 padding-b-60 align-center" data-ckav-smd="padding-tb-30" data-ckav-md="padding-b-60">
                        <div class="zindex-2 ckav-shap height-px-100">
                            <img src="images/wave.png" alt="image">
                        </div>

                        <h2 class="heading-section large bold-600" data-ckav-smd="default">Hakkımda</h2>
                    </div>

                    <div class="container">
                        <div class="story-area padding-tb-mini">
                            <div class="row align-items-center gt60">

                                <!-- IMAGES -->
                                <div class="col-lg-6" data-ckav-smd="margin-b-30">
                                    <img class="radius-10" src="<?php echo ayar('about_image'); ?>" alt="image">
                                </div>
        
                                <!-- CONTENT -->
                                <div class="col-lg-6" data-ckav-smd="align-center">
                                    <h3 class="heading-content bold-600 medium" data-ckav-smd="small"><?php echo ayar('about_01'); ?></h3>
                                    <p class="heading-content-sub mini bold-400 margin-b-30" data-ckav-smd="tiny margin-b-30"><?php echo ayar('about_02'); ?></p>
                                    <p class="margin-b-30">
                                        <?php echo nl2br(ayar('about_03')); ?>
                                    </p>
                                </div>
        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ======= END : ABOUT =======  -->

            <!--=================================
            = SERVICES
            ==================================-->
            <div id="services" class="services-page page-wrapper">
                <div class="inner-wrapper">
                    <!-- PAGE HEADER -->
                    <div class="page-header-area bgcolor-default typo-light padding-t-40 padding-b-60 align-center" data-ckav-smd="padding-tb-30" data-ckav-md="padding-b-60">
                        <div class="zindex-2 ckav-shap height-px-100">
                            <img src="images/wave.png" alt="image">
                        </div>

                        <h2 class="heading-section large bold-600" data-ckav-smd="default">Hizmetlerim</h2>
                    </div>

                    <div class="container">
                        <div class="services-area padding-tb-mini">

                            <div class="row align-items-center">
                                <?php foreach($servicesStore->findAll() as $servicesVal): ?>
                                <div class="col-md-6">
                                    <div class="info-obj radius-10 info-box-01 img-l padding-30 gap-20 mini" data-bg-color="rgba(0,0,0,0.03)">
                                        <div class="img"><span class="iconwrp"><i class="<?php echo $servicesVal['icon']; ?>"></i></span></div>
                                        <div class="info">
                                            <h3 class="heading-content bold-600 tiny"><?php echo $servicesVal['title']; ?></h3>
                                            <p class="margin-b-0"><?php echo $servicesVal['description']; ?></p>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
        
                            </div>
                        </div>

                        <div class="services-area padding-tb-mini">

                            <div class="width-50 margin-auto align-center margin-b-40" data-ckav-smd="width-100">
                                <h3 class="heading-content bold-600 medium" data-ckav-smd="small">Yeteneklerim</h3>
                            </div>

                            <div class="row">
                            
                                    <?php foreach($skillsStore->findAll() as $skillsVal): ?>
                                    <div class="col-12 col-md-6">
                                    <div class="skill-box margin-b-30">
                                        <div class="skill-text">
                                            <h3 class="heading-content text-italic tiny margin-b-10"><?php echo $skillsVal['title']; ?></h3>
                                        </div>
                                        <div class="skill-bar radius-10">
                                            <div class="skill-progress radius-10 width-<?php echo $skillsVal['percent']; ?>">
                                                <div class="skill-count">
                                                    <?php echo $skillsVal['percent']; ?>%
                                                    <span class="icon"><i class="fas fa-sort-down"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                    <?php endforeach; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ======= END : SERVICES =======  -->

            <!--=================================
            = PORTFOLIO
            ==================================-->
            <div id="portfolio" class="portfolio-page page-wrapper">
                <div class="inner-wrapper">
                    <!-- PAGE HEADER -->
                    <div class="page-header-area bgcolor-default typo-light padding-t-40 padding-b-60 align-center" data-ckav-smd="padding-tb-30" data-ckav-md="padding-b-60">
                        <div class="zindex-2 ckav-shap height-px-100">
                            <img src="images/wave.png" alt="image">
                        </div>

                        <h2 class="heading-section large bold-600" data-ckav-smd="default">Portfolyo</h2>
                    </div>

                    <div class="container">
                        <div class="portfolio-area padding-tb-mini">
                            <div class="portfolio-widget grid-portfolio portfolio-row grid-03" data-zoom-gallery="yes" data-ckav-md="grid-02" data-ckav-sm="grid-01">
                                <?php foreach($photosStore->findAll() as $portfolioVal): ?>
                                <div class="portfolio-col">
                                    <figure class="hover-box hover-box-01">
                                        
                                        <!-- OVERLAY -->
                                        <div class="overlay flex-bl typo-light" data-linear-gradient="rgba(31,34,41,0.5)|rgba(31,34,41,1)">
                                            <div class="info-text text-center">
                                                <a href="<?php echo $portfolioVal['image']; ?>" class="zoom-img button button-icon radius-full margin-lr-5 color-button-default solid"><i class="icon-size-fullscreen"></i></a>
                                                <h3 class="heading-content tiny bold-600 margin-b-5 margin-t-30"><?php echo $portfolioVal['title']; ?></h3>
                                                <p class="mr-0 fs12 op-08"><?php echo $portfolioVal['description']; ?></p>
                                            </div>
                                        </div>
                                        <!-- IMAGE -->
                                        <img src="<?php echo $portfolioVal['image']; ?>" alt="<?php echo $portfolioVal['title']; ?>">
                                    </figure>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ======= END : PORTFOLIO =======  -->

            <!--=================================
            = TESTIMONIALS
            ==================================-->
            <div id="testimonials" class="testimonials-page page-wrapper">
                <div class="inner-wrapper">
                    <!-- PAGE HEADER -->
                    <div class="page-header-area bgcolor-default typo-light padding-t-40 padding-b-60 align-center" data-ckav-smd="padding-tb-30" data-ckav-md="padding-b-60">
                        <div class="zindex-2 ckav-shap height-px-100">
                            <img src="images/wave.png" alt="image">
                        </div>

                        <h2 class="heading-section large bold-600" data-ckav-smd="default">Ne Dediler?</h2>
                    </div>

                    <div class="container">
                        <div class="testimonials-area padding-tb-mini padding-t-0">

                            <div class="carousel-widget carouselnav-1 zoom-carousel large padding-b-0 width-90 margin-auto" data-ckav-smd="width-100 align-center" 
                            data-carousel-items="1"
                            data-carousel-itemrange="0,1|420,1|600,2|768,3|992,3|1200,3"
                            data-carousel-autoplay="false" 
                            data-carousel-margin="30" 
                            data-carousel-loop="true"
                            data-carousel-nav="true"
                            data-carousel-dots="true"
                            data-carousel-center="true">
                                <div class="owl-carousel">
                                    <?php foreach($testimonialsStore->findAll() as $testimonialsVal): ?>
                                    <div class="item">
                                        <div class="inneritem">
                                            <div class="testimonial-box testimonial-box-5 padding-30 radius-10 info-obj img-t center gap-30 large">
                                                <div class="img border-white border-10"><img src="<?php echo $testimonialsVal['image']; ?>" class="radius-full" alt="<?php echo $testimonialsVal['title']; ?>"></div>
                                                <div class="info">
                                                    <p class="heading-content-sub tiny margin-0"><?php echo $testimonialsVal['description']; ?></p>
                                                    <hr class="margin-tb-20">
                                                    <h3 class="heading-content tiny bold-600 margin-0"><?php echo $testimonialsVal['title']; ?></h3>
                                                    <em class="fs12"><?php echo $testimonialsVal['title_alt']; ?></em>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
            
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- ======= END : TESTIMONIALS =======  -->

            <!--=================================
            = CONTACT
            ==================================-->
            <div id="contact" class="contact-page page-wrapper">
                <div class="inner-wrapper">
                    <!-- PAGE HEADER -->
                    <div class="page-header-area bgcolor-default typo-light padding-t-40 padding-b-60 align-center" data-ckav-smd="padding-tb-30" data-ckav-md="padding-b-60">
                        <div class="zindex-2 ckav-shap height-px-100">
                            <img src="images/wave.png" alt="image">
                        </div>

                        <h2 class="heading-section large bold-600" data-ckav-smd="default">İletişim</h2>
                    </div>

                    <div class="container">

                        <div class="contact-area padding-tb-mini">

                            <div class="row gt0 align-items-center">
                                <div class="col-lg-4">
                                    <div class="info-obj margin-b-0 center info-box-01 img-t gap-20 mini padding-30 radius-10" data-bg-color="rgba(0,0,0,0.02)" data-ckav-smd="margin-b-30 align-left">
                                        <div class="img"><span class="iconwrp"><i class="pe-7s-mail"></i></span></div>
                                        <div class="info">
                                            <h3 class="heading-content tiny bold-600 margin-b-5">E-Posta</h3>
                                            <p class="margin-b-0"><a href="mailto:<?php echo ayar('contact_email'); ?>"><?php echo ayar('contact_email'); ?></a></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="info-obj margin-b-0 center info-box-01 img-t gap-20 mini padding-30 radius-10 padding-tb-40 bgcolor-dark typo-light" data-ckav-smd="margin-b-30 align-left">
                                        <div class="img"><span class="iconwrp"><i class="pe-7s-map-2"></i></span></div>
                                        <div class="info">
                                            <h3 class="heading-content tiny bold-600 margin-b-5">Adres</h3>
                                            <p class="margin-b-0"><?php echo ayar('contact_address'); ?></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="info-obj margin-b-0 center info-box-01 img-t gap-20 mini padding-30 radius-10" data-bg-color="rgba(0,0,0,0.02)" data-ckav-smd="margin-b-30 align-left">
                                        <div class="img"><span class="iconwrp"><i class="pe-7s-headphones"></i></span></div>
                                        <div class="info">
                                            <h3 class="heading-content tiny bold-600 margin-b-5">Telefon</h3>
                                            <p class="margin-b-0"><a href="tel:<?php echo ayar('contact_tel'); ?>"><?php echo ayar('contact_tel'); ?></a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="map-area padding-b-mini">
                            <div class="map-wrapper height-px-300 margin-b-40">
                                <iframe class="width-100 height-100 border-none" src="<?php echo ayar('contact_googlemap'); ?>" allowfullscreen></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ======= END : CONTACT =======  -->

            <div class="ckav-footer-area">
                <div class="inner-wrapper">
                    <div class="container-fluid padding-0">
                        <div class="row align-items-center height-px-100" data-ckav-sm="align-center">
    
                            <!-- SOCIAL ICONS -->
                            <div class="col-md-6">
                                <div class="social-section" data-ckav-sm="-margin-b-20">
                                    <div>
                                        <?php if(!empty(ayar('social_imdb'))): ?>
                                        <a href="<?php echo ayar('social_imdb'); ?>" class="button button-icon radius-full margin-r-10 color-button-white border-glass" target="_blank"><i class="fab fa-imdb"></i></a>
                                        <?php endif; ?>
                                        
                                        <?php if(!empty(ayar('social_instagram'))): ?>
                                        <a href="<?php echo ayar('social_instagram'); ?>" class="button button-icon radius-full margin-r-10 color-button-white border-glass" target="_blank"><i class="fab fa-instagram"></i></a>
                                        <?php endif; ?>
                                        
                                        <?php if(!empty(ayar('social_facebook'))): ?>
                                        <a href="<?php echo ayar('social_facebook'); ?>" class="button button-icon radius-full margin-r-10 color-button-white border-glass" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                        <?php endif; ?>
                                        
                                        <?php if(!empty(ayar('social_twitter'))): ?>
                                        <a href="<?php echo ayar('social_twitter'); ?>" class="button button-icon radius-full margin-r-10 color-button-white border-glass" target="_blank"><i class="fab fa-twitter"></i></a>
                                        <?php endif; ?>
                                        
                                        <?php if(!empty(ayar('social_linkedin'))): ?>
                                        <a href="<?php echo ayar('social_linkedin'); ?>" class="button button-icon radius-full margin-r-10 color-button-white border-glass" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                                        <?php endif; ?>
                                        
                                        
                                    </div>
                                </div>
                            </div>
    
                            <!-- COPYRIGHT -->
                            <div class="col-md-6 align-right color-text-white" data-ckav-sm="align-center">
                                <?php echo ayar('site_title'); ?> © <script>document.write(new Date().getFullYear());</script>
                            </div>
    
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- ************** END : SUB PAGES **************  -->

    </div>
    
<!-- COMMON VENDOR SCRIPTS -->
<script src="vendor/jquery/jquery-3.3.1.min.js"></script>
<script src="vendor/jquery/jquery-migrate-3.0.0.min.js"></script>
<script src="vendor/popper/umd/popper.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="vendor/jquery-validation/jquery.validate.min.js"></script>
<script src="vendor/sweetalert/sweetalert2.min.js"></script>
<script src="vendor/jarallax/jarallax.min.js"></script>
<script src="vendor/owlcarousel/owl.carousel.min.js"></script>
<script src="vendor/swiper/js/swiper.min.js"></script>
<script src="vendor/jQuery-viewport-checker/jquery.viewportchecker.min.js"></script>
<script src="vendor/enquire/enquire.min.js"></script>
<script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="vendor/isotope/imagesloaded.pkgd.min.js"></script>
<script src="vendor/isotope/isotope.pkgd.min.js"></script>
<script src="vendor/isotope/packery-mode.pkgd.min.js"></script>

<!-- PAGE SPECIFIC VENDOR SCRIPTS -->
<script src="vendor/particle-animation/particles.min.js"></script>	
<script src="vendor/particle-animation/partical-animation.js"></script>	

<!-- TEMPLATE COMMON SCRIPTS -->
<script src="js/ckav-main.js"></script>


</body>
</html>