<?php

?>
</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.0.18/sweetalert2.min.js"></script>
<script src="https://cdn.ckeditor.com/4.16.1/standard/ckeditor.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ckeditor/4.16.1/lang/tr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>

  function confirm_delete() {
    var x = confirm("Really want to remove?");
    if (x)
      return true;
    else
      return false;
  }
  <?php if (isset($output)): ?>
    Swal.fire({
      title: 'Başarılı!',
      text: 'Değişiklikler kaydedildi.',
      icon: 'success',
      showConfirmButton: false,
      timer: 2000
    }).then((result) => {
      <?php if(isset($redirect)){ ?>
      window.location.href = "<?php echo post_redirect(); ?>";
      <?php } ?>
    });
    <?php endif; ?>
</script>
<script>
  window.addEventListener('DOMContentLoaded', event => {
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
      sidebarToggle.addEventListener('click', event => {
        event.preventDefault();
        document.body.classList.toggle('sb-sidenav-toggled');
        localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
      });
    }
  });
</script>
</body>

</html>