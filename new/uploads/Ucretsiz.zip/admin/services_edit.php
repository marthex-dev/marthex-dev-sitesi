<?php
include('header.php');
include('../inc/config.php');
$identy = $servicesStore;
if(isset($_GET['id'])){
	$id = $_GET['id'];
}
$datas = $identy->findById($id);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$datas = elements(['icon','title','description']);
$process = $identy->update($datas);
$output = '';
$redirect = '';
}
?>
<div class="container-fluid mt-4">
<form method="POST" action="" enctype="multipart/form-data">
  
  <div class="form-outline mb-4">
	  <label for="icon" class="form-label">Ikon:</label>
	  <input type="text" id="icon" name="icon" class="form-control" value="<?php echo $datas['icon']; ?>">
	  <small class="d-block mt-2">Ikon seçmek için <a href="https://themes-pixeden.com/font-demos/7-stroke/" target="_blank">tıklayınız.</a> örnek: <b>pe-7s-album</b></small>
  </div>
  
  <div class="form-outline mb-4">
	<label for="title" class="form-label">Başlık:</label>
	<input type="text" id="title" name="title" class="form-control" value="<?php echo $datas['title']; ?>">
  </div>
  
  <div class="form-outline mb-4">
  <label for="description" class="form-label">Açıklama:</label>
  <textarea class="form-control" name="description" id="description" rows="5"><?php echo $datas['description']; ?></textarea>
  </div>

	<input type="submit" class="btn btn-primary btn-block mb-4" value="İşlemi Onayla" />
  </form>
</div>
<?php include('footer.php'); ?>