<?php
include('../inc/config.php');
$datas = $settingsStore->findById(1);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$datas = elements(['homepage_01','homepage_02']);
$updateLogo = updateFile($datas['homepage_image'],'homepage_image','main',0);
if(!empty($updateLogo)):
$datas['homepage_image'] = $updateLogo;
endif;
$datas["_id"] = 1;
$settingsStore->update($datas);
$output = '';
}
include('header.php');
?>
<div class="container-fluid mt-4">
<form method="POST" action="" enctype="multipart/form-data">
  
  <div class="mb-3">
    <label for="homepage_image" class="form-label">Anasayfa Fotoğraf:</label>
    <img src="../<?php echo $datas['homepage_image']; ?>" class="img-thumbnail d-block mb-2" alt="" style="max-width:200px;">
    <input class="form-control" type="file" id="homepage_image" name="homepage_image">
    <small class="d-block mt-2">1920x1080 px</small>
  </div>

  <div class="form-outline mb-4">
    <label for="homepage_01" class="form-label">Anasayfa Başlık:</label>
    <input type="text" id="homepage_01" name="homepage_01" class="form-control" value="<?php echo $datas['homepage_01']; ?>" required>
  </div>
  
  <div class="form-outline mb-4">
    <label for="homepage_02" class="form-label">Anasayfa Açıklama:</label>
    <input type="text" id="homepage_02" name="homepage_02" class="form-control" value="<?php echo $datas['homepage_02']; ?>" required>
  </div>

  <input type="submit" class="btn btn-primary btn-block mb-4" value="İşlemi Onayla" />
  </form>
</div>
<?php include('footer.php'); ?>