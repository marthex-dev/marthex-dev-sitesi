<?php
include('header.php');
include('../inc/config.php');
$identy = $testimonialsStore;
$datasCount = $identy->count();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$datas = elements(['title','title_alt','description']);
$datas["slug"] = slug($datas["title"]);
$datas["image"] = uploadFile('image','testimonials',0);
$process = $identy->insert($datas);
$output = '';
$redirect = '';
}
?>
<div class="container-fluid mt-4">
<form method="POST" action="" enctype="multipart/form-data">
	<div class="form-outline mb-4">
		<label for="title" class="form-label">Müşteri Adı:</label>
		<input type="text" id="title" name="title" class="form-control" value="">
	</div>
	
	<div class="form-outline mb-4">
		<label for="title_alt" class="form-label">Müşteri Tanımı:</label>
		<input type="text" id="title_alt" name="title_alt" class="form-control" value="">
	</div>
	
	<div class="form-outline mb-4">
		<label for="description" class="form-label">Açıklama:</label>
		<input type="text" id="description" name="description" class="form-control" value="">
	</div>
	
	<div class="mb-3">
	  <label for="image" class="form-label">Görsel:</label>
	  <input class="form-control" type="file" id="image" name="image">
	  <small class="d-block mt-2">400x400 px</small>
	</div>
	<input type="submit" class="btn btn-primary btn-block mb-4" value="İşlemi Onayla" />
  </form>
</div>
<?php include('footer.php'); ?>