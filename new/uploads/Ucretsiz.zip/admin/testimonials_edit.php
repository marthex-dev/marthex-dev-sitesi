<?php

include('header.php');
include('../inc/config.php');
$identy = $testimonialsStore;
if(isset($_GET['id'])){
	$id = $_GET['id'];
}
$datas = $identy->findById($id);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$datas = elements(['title','title_alt','description']);
$updateFile = updateFile($datas['image'],'image','testimonials',0);
if(!empty($updateFile)):
$datas['image'] = $updateFile;
endif;
$process = $identy->update($datas);
$output = '';
$redirect = '';
}
?>
<div class="container-fluid mt-4">
<form method="POST" action="" enctype="multipart/form-data">

  <div class="form-outline mb-4">
	<label for="title" class="form-label">Müşteri Adı:</label>
	<input type="text" id="title" name="title" class="form-control" value="<?php echo $datas['title']; ?>">
  </div>
  
  <div class="form-outline mb-4">
	<label for="title_alt" class="form-label">Müşteri Tanımı:</label>
	<input type="text" id="title_alt" name="title_alt" class="form-control" value="<?php echo $datas['title_alt']; ?>">
  </div>
  
  <div class="form-outline mb-4">
	<label for="description" class="form-label">Açıklama:</label>
	<input type="text" id="description" name="description" class="form-control" value="<?php echo $datas['description']; ?>">
  </div>

  <div class="mb-3">
	  <label for="image" class="form-label">Görsel:</label>
	  <?php if(!empty($datas['image'])): ?>
	  <img src="../<?php echo $datas['image']; ?>" class="img-thumbnail d-block mb-2" style="max-height:200px;" alt="">
	  <?php endif; ?>
	  <input class="form-control" type="file" id="image" name="image">
	  <small class="d-block mt-2">400x400 px</small>
	</div>

	<input type="submit" class="btn btn-primary btn-block mb-4" value="İşlemi Onayla" />
  </form>
</div>
<?php include('footer.php'); ?>