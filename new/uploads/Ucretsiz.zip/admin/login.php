<?php

session_start();
include('../inc/config.php');
if(isset($_SESSION['login'])) {
	header("Location: index.php"); die();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$password = md5($_POST['admin_password']);
if($password === ayar('admin_password')){
	$_SESSION['login'] = true; header("Location: index.php"); die();
} {
	$output = "<div class='alert alert-danger'>Şifre yanlış.</div>";
}
}
?>
<!doctype html>
<html lang="ro">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Panel</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css" rel="stylesheet">
  <link rel="icon" href="../<?php echo $settings['site_favicon']; ?>">
  <style>
    html,
    body {
      height: 100%;
    }
    body {
      display: flex;
      align-items: center;
      padding-top: 40px;
      padding-bottom: 40px;
      background-color: #f5f5f5;
    }
    .form-signin {
      width: 100%;
      max-width: 330px;
      padding: 15px;
      margin: auto;
    }
    .form-signin .form-floating:focus-within {
      z-index: 2;
    }
  </style>
</head>
<body class="text-center">
  <main class="form-signin">
    <form action="" method="post">
    <img class="mb-4" src="../<?php echo $settings['site_logo']; ?>" alt="" width="140">
    <h1 class="h4 mb-3 fw-normal">Admin Panel</h1>
      <div class="form-floating">
        <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="admin_password">
        <label for="floatingPassword">Şifre</label>
      </div>
      <?php if(!empty($output)){echo $output;}?>
      <button class="w-100 btn btn-primary mt-2" type="submit">Giriş Yap</button>
    </form>
  </main>
</body>
</html>
