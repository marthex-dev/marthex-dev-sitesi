<?php
include('header.php');
include('../inc/config.php');
$identy = $photosStore;
rmData($identy,'image');
$datas = $identy->createQueryBuilder()->orderBy(["_id" => "desc"])->getQuery()->fetch();
?>
<div class="container-fluid mt-4">
  <table class="table table-striped">
	<thead>
	  <tr class="d-flex">
		<th class="col">Başlık</th>
		<th class="col">İşlem</th>
	  </tr>
	</thead>
	<tbody>
	  <?php foreach($datas as $value): ?>
	  <tr class="d-flex">
		<td class="col"><?php echo $value['title']; ?></td>
		<td class="col">
		  <div class="btn-group">
			<a href="photos_edit.php?id=<?php echo $value['_id']; ?>" class="btn btn-primary">Düzenle</a>
			<a href="photos_all.php?id=<?php echo $value['_id']; ?>" class="btn btn-danger" onclick="return confirm_delete()">Sil</a>
		  </div>
		</td>
	  </tr>
	  <?php endforeach; ?>
	</tbody>

  </table>
</div>
<?php include('footer.php'); ?>
