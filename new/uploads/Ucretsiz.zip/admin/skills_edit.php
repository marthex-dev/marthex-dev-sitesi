<?php
include('header.php');
include('../inc/config.php');
$identy = $skillsStore;
if(isset($_GET['id'])){
	$id = $_GET['id'];
}
$datas = $identy->findById($id);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$datas = elements(['title','percent']);
$process = $identy->update($datas);
$output = '';
$redirect = '';
}
?>
<div class="container-fluid mt-4">
<form method="POST" action="" enctype="multipart/form-data">

  <div class="form-outline mb-4">
	<label for="title" class="form-label">Başlık:</label>
	<input type="text" id="title" name="title" class="form-control" value="<?php echo $datas['title']; ?>">
  </div>
  
  <div class="form-outline mb-4">
	<label for="percent" class="form-label">Yüzde Değeri:</label>
	<input type="number" id="percent" name="percent" class="form-control" value="<?php echo $datas['percent']; ?>">
  </div>

	<input type="submit" class="btn btn-primary btn-block mb-4" value="İşlemi Onayla" />
  </form>
</div>
<?php include('footer.php'); ?>