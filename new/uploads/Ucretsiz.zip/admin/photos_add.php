<?php
include('header.php');
include('../inc/config.php');
$identy = $photosStore;
$datasCount = $identy->count();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$datas = elements(['title','description']);
$datas["slug"] = slug($datas["title"]);
$datas["image"] = uploadFile('image','photos',0);
$process = $identy->insert($datas);
$output = '';
$redirect = '';
}
?>
<div class="container-fluid mt-4">
<form method="POST" action="" enctype="multipart/form-data">
	<div class="form-outline mb-4">
		<label for="title" class="form-label">Başlık:</label>
		<input type="text" id="title" name="title" class="form-control" value="">
	</div>
	
	<div class="form-outline mb-4">
		<label for="description" class="form-label">Açıklama:</label>
		<input type="text" id="description" name="description" class="form-control" value="">
	</div>
	
	<div class="mb-3">
	  <label for="image" class="form-label">Görsel:</label>
	  <input class="form-control" type="file" id="image" name="image">
	  <small class="d-block mt-2">800x800 px</small>
	</div>
	<input type="submit" class="btn btn-primary btn-block mb-4" value="İşlemi Onayla" />
  </form>
</div>
<?php include('footer.php'); ?>