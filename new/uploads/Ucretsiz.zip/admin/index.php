<?php

include('../inc/config.php');
$datas = $settingsStore->findById(1);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$datas = elements(['site_title','site_description','site_keywords','contact_email','contact_tel','contact_address','contact_googlemap','social_instagram','social_facebook','social_twitter','social_youtube','social_imdb','social_linkedin']);
if(!empty($_POST['admin_password'])){
$datas["admin_password"] = md5($_POST['admin_password']);
}
$updateLogo = updateFile($datas['site_logo'],'site_logo','main',0);
if(!empty($updateLogo)):
$datas['site_logo'] = $updateLogo;
endif;
$updateFavicon = updateFile($datas['site_favicon'],'site_favicon','main',0);
if(!empty($updateFavicon)):
$datas['site_favicon'] = $updateFavicon;
endif;
$datas["_id"] = 1;
$settingsStore->update($datas);
$output = '';
}
include('header.php');
?>
<div class="container-fluid mt-4">
<form method="POST" action="" enctype="multipart/form-data">
  
  <div class="form-outline mb-4">
    <label for="site_title" class="form-label">Site Başlık:</label>
    <input type="text" id="site_title" name="site_title" class="form-control" value="<?php echo $datas['site_title']; ?>">
  </div>

  <div class="form-outline mb-4">
    <label for="site_description" class="form-label">Site Açıklama:</label>
    <input type="text" id="site_description" name="site_description" class="form-control" value="<?php echo $datas['site_description']; ?>">
  </div>

  <div class="form-outline mb-4">
    <label for="site_keywords" class="form-label">Site Anahtar Kelimeler:</label>
    <input type="text" id="site_keywords" name="site_keywords" class="form-control" value="<?php echo $datas['site_keywords']; ?>">
  </div>
  
  <div class="mb-3">
    <label for="site_logo" class="form-label">Site Logo:</label>
    <img src="../<?php echo $datas['site_logo']; ?>" class="img-thumbnail d-block mb-2" alt="" style="max-width:200px;">
    <input class="form-control" type="file" id="site_logo" name="site_logo">
    <small class="d-block mt-2">171x50 px</small>
  </div>

  <div class="mb-3">
    <label for="site_favicon" class="form-label">Site Favicon:</label>
    <img src="../<?php echo $datas['site_favicon']; ?>" class="img-thumbnail d-block mb-2" alt="">
    <input class="form-control" type="file" id="site_favicon" name="site_favicon">
  </div>
  
  <div class="p-3 bg-white text-dark mb-4 rounded-3">
  <h2 class="m-0 fs-5 mb-3">İletişim Ayarları</h2>
    
  <div class="form-outline mb-4">
    <label for="contact_email" class="form-label">İletişim E-mail:</label>
    <input type="email" id="contact_email" name="contact_email" class="form-control" value="<?php echo $datas['contact_email']; ?>">
  </div>
  
  <div class="form-outline mb-4">
    <label for="contact_tel" class="form-label">Telefon:</label>
    <input type="tel" id="contact_tel" name="contact_tel" class="form-control" value="<?php echo $datas['contact_tel']; ?>">
  </div>
  
  <div class="form-outline mb-4">
    <label for="contact_address" class="form-label">Adres:</label>
    <textarea class="form-control" name="contact_address" id="contact_address" rows="5"><?php echo $datas['contact_address']; ?></textarea>
  </div>
  
  <div class="form-outline mb-4">
    <label for="contact_googlemap" class="form-label">Google Map:</label>
    <textarea class="form-control" name="contact_googlemap" id="contact_googlemap" rows="5"><?php echo $datas['contact_googlemap']; ?></textarea>
  </div>

  </div>
  
  <div class="p-3 bg-white text-dark mb-4 rounded-3">
  <h2 class="m-0 fs-5 mb-2">Sosyal Medya</h2>
    
  <div class="form-outline mb-4">
    <label for="social_linkedin" class="form-label">Linkedin:</label>
    <input type="text" id="social_linkedin" name="social_linkedin" class="form-control" value="<?php echo $datas['social_linkedin']; ?>">
  </div>
  
  <div class="form-outline mb-4">
    <label for="social_instagram" class="form-label">Instagram:</label>
    <input type="text" id="social_instagram" name="social_instagram" class="form-control" value="<?php echo $datas['social_instagram']; ?>">
  </div>
  
  <div class="form-outline mb-4">
    <label for="social_facebook" class="form-label">Facebook:</label>
    <input type="text" id="social_facebook" name="social_facebook" class="form-control" value="<?php echo $datas['social_facebook']; ?>">
  </div>
  
  <div class="form-outline mb-4">
    <label for="social_twitter" class="form-label">Twitter:</label>
    <input type="text" id="social_twitter" name="social_twitter" class="form-control" value="<?php echo $datas['social_twitter']; ?>">
  </div>
  
  <div class="form-outline mb-4">
    <label for="social_youtube" class="form-label">Youtube:</label>
    <input type="text" id="social_youtube" name="social_youtube" class="form-control" value="<?php echo $datas['social_youtube']; ?>">
  </div>
  
  <div class="form-outline">
    <label for="social_imdb" class="form-label">IMDB:</label>
    <input type="text" id="social_imdb" name="social_imdb" class="form-control" value="<?php echo $datas['social_imdb']; ?>">
  </div>
  
  </div>

  <div class="form-outline mb-4">
    <label for="admin_password" class="form-label">Admin Şifre:</label>
    <input type="password" id="admin_password" name="admin_password" class="form-control">
    <small>Sadece değiştirecekseniz giriniz.</small>
  </div>
  <input type="submit" class="btn btn-primary btn-block mb-4" value="İşlemi Onayla" />
  </form>
</div>
<?php include('footer.php'); ?>