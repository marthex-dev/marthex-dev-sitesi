<?php
session_start();
include('../inc/config.php');
if(!isset($_SESSION['login'])){
	header("Location: login.php");
  die();
}
?>
<!doctype html>
<html lang="tr" class="h-100">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <title><?php echo $settings['site_title']; ?> Admin Panel</title>
  <link rel="canonical" href="">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.5.0/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.0.18/sweetalert2.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.1.1/dist/select2-bootstrap-5-theme.min.css" />
  <link href="admin.css?v=7" rel="stylesheet">
  <link rel="icon" href="../<?php echo $settings['site_favicon']; ?>">
  <style>
  #content{
    min-height: 220px;
  }
  </style>
</head>

<body>
  <div class="d-flex" id="wrapper">
      <div class="bg-dark" id="sidebar-wrapper">
        <div class="sidebar-heading bg-dark fs-6 text-center"><a href="./index.php" class="link-light text-decoration-none border-bottom">Admin <b class="fw-600">Panel</b></a></div>
        <nav class="navbar py-0">
          <ul class="nav navbar-nav w-100 rounded-0">
            <li class="nav-item dropdown">
              <a class="nav-link link-light px-4 py-3 dropdown-toggle box-sh-none py-2 <?php echo active(['photos_add.php','photos_all.php','photos_edit.php']); ?> <?php echo show(['photos_add.php','photos_all.php','photos_edit.php']); ?>" href="#" id="sidebarMenu" role="button" data-bs-toggle="dropdown" aria-expanded="<?php echo expanded(['photos_add.php','photos_all.php','photos_edit.php']); ?>">
              <i class="bi bi-images"></i> Portfolyo
              </a>
              <ul class="dropdown-menu bg-transparent rounded-0 border-0 py-0 <?php echo show(['photos_add.php','photos_all.php','photos_edit.php']); ?>" aria-labelledby="sidebarMenu">
              <li><a class="dropdown-item py-2 px-4 <?php echo active(['photos_add.php']); ?>" href="photos_add.php">Yeni Ekle</a></li>
              <li><a class="dropdown-item py-2 px-4 <?php echo active(['photos_all.php']); ?>" href="photos_all.php">Tümünü Göster</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link link-light px-4 py-3 dropdown-toggle box-sh-none py-2 <?php echo active(['skills_add.php','skills_all.php','skills_edit.php']); ?> <?php echo show(['skills_add.php','skills_all.php','skills_edit.php']); ?>" href="#" id="sidebarMenu" role="button" data-bs-toggle="dropdown" aria-expanded="<?php echo expanded(['skills_add.php','skills_all.php','skills_edit.php']); ?>">
              <i class="bi bi-images"></i> Yetenekler
              </a>
              <ul class="dropdown-menu bg-transparent rounded-0 border-0 py-0 <?php echo show(['skills_add.php','skills_all.php','skills_edit.php']); ?>" aria-labelledby="sidebarMenu">
              <li><a class="dropdown-item py-2 px-4 <?php echo active(['skills_add.php']); ?>" href="skills_add.php">Yeni Ekle</a></li>
              <li><a class="dropdown-item py-2 px-4 <?php echo active(['skills_all.php']); ?>" href="skills_all.php">Tümünü Göster</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link link-light px-4 py-3 dropdown-toggle box-sh-none py-2 <?php echo active(['services_add.php','services_all.php','services_edit.php']); ?> <?php echo show(['services_add.php','services_all.php','services_edit.php']); ?>" href="#" id="sidebarMenu" role="button" data-bs-toggle="dropdown" aria-expanded="<?php echo expanded(['services_add.php','services_all.php','services_edit.php']); ?>">
              <i class="bi bi-images"></i> Hizmetler
              </a>
              <ul class="dropdown-menu bg-transparent rounded-0 border-0 py-0 <?php echo show(['services_add.php','services_all.php','services_edit.php']); ?>" aria-labelledby="sidebarMenu">
              <li><a class="dropdown-item py-2 px-4 <?php echo active(['services_add.php']); ?>" href="services_add.php">Yeni Ekle</a></li>
              <li><a class="dropdown-item py-2 px-4 <?php echo active(['services_all.php']); ?>" href="services_all.php">Tümünü Göster</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link link-light px-4 py-3 dropdown-toggle box-sh-none py-2 <?php echo active(['testimonials_add.php','testimonials_all.php','testimonials_edit.php']); ?> <?php echo show(['testimonials_add.php','testimonials_all.php','testimonials_edit.php']); ?>" href="#" id="sidebarMenu" role="button" data-bs-toggle="dropdown" aria-expanded="<?php echo expanded(['testimonials_add.php','testimonials_all.php','testimonials_edit.php']); ?>">
              <i class="bi bi-images"></i> Ne Dediler?
              </a>
              <ul class="dropdown-menu bg-transparent rounded-0 border-0 py-0 <?php echo show(['testimonials_add.php','testimonials_all.php','testimonials_edit.php']); ?>" aria-labelledby="sidebarMenu">
              <li><a class="dropdown-item py-2 px-4 <?php echo active(['testimonials_add.php']); ?>" href="testimonials_add.php">Yeni Ekle</a></li>
              <li><a class="dropdown-item py-2 px-4 <?php echo active(['testimonials_all.php']); ?>" href="testimonials_all.php">Tümünü Göster</a></li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link link-light px-4 py-3 <?php echo active(['index.php']); ?>" href="index.php"><i class="bi bi-gear"></i> Site Ayarları</a>
            </li>
            <li class="nav-item">
              <a class="nav-link link-light px-4 py-3 <?php echo active(['about.php']); ?>" href="about.php"><i class="bi bi-gear"></i> Hakkımda</a>
            </li>
            <li class="nav-item">
              <a class="nav-link link-light px-4 py-3 <?php echo active(['homepage.php']); ?>" href="homepage.php"><i class="bi bi-gear"></i> Anasayfa</a>
            </li>
          </ul>
        </nav>
      </div>
        <div id="page-content-wrapper" class="bg-light">
          <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
              <button class="btn btn-dark fs-6 text-white fw-normal text-uppercase" id="sidebarToggle"><i class="bi bi-arrow-bar-left"></i></button>
              <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                  <li class="nav-item"><a class="nav-link text-white" href="../" target="_blank"><i class="bi bi-eye"></i> Siteyi Göster</a></li>
                  <li class="nav-item"><a class="nav-link text-white" href="logout.php"><i class="bi bi-box-arrow-right"></i> Çıkış</a></li>
                </ul>
              </div>
            </div>
          </nav>