<?php
require_once __DIR__ . "/src/Store.php";
$dbConfig = ["auto_cache" => false,"cache_lifetime" => null,"timeout" => false];
$databaseDirectory = __DIR__ . "/db";
$settingsStore = new \SleekDB\Store("settings", $databaseDirectory, $dbConfig);
$photosStore = new \SleekDB\Store("photos", $databaseDirectory, $dbConfig);
$testimonialsStore = new \SleekDB\Store("testimonials", $databaseDirectory, $dbConfig);
$servicesStore = new \SleekDB\Store("services", $databaseDirectory, $dbConfig);
$skillsStore = new \SleekDB\Store("skills", $databaseDirectory, $dbConfig);
$settings = $settingsStore->findById(1);
$allowedExtensions = array("jpg","png","jpeg","gif","webp","bmp","svg","ico","JPEG","JPG");
$allowedCompress = array("jpg","jpeg","png","JPEG","JPG");
?>