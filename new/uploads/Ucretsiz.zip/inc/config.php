<?php
date_default_timezone_set("Europe/Istanbul");
include_once('functions.php');
require_once('db.php');
?>