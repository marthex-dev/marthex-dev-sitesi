<?php
function slug($text){
	// replace non letter or digits by -
	$a = array('À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ć', 'ć', 'Ĉ', 'ĉ', 'Ċ', 'ċ', 'Č', 'č', 'Ď', 'ď', 'Đ', 'đ', 'Ē', 'ē', 'Ĕ', 'ĕ', 'Ė', 'ė', 'Ę', 'ę', 'Ě', 'ě', 'Ĝ', 'ĝ', 'Ğ', 'ğ', 'Ġ', 'ġ', 'Ģ', 'ģ', 'Ĥ', 'ĥ', 'Ħ', 'ħ', 'Ĩ', 'ĩ', 'Ī', 'ī', 'Ĭ', 'ĭ', 'Į', 'į', 'İ', 'ı', 'Ĳ', 'ĳ', 'Ĵ', 'ĵ', 'Ķ', 'ķ', 'Ĺ', 'ĺ', 'Ļ', 'ļ', 'Ľ', 'ľ', 'Ŀ', 'ŀ', 'Ł', 'ł', 'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'ŉ', 'Ō', 'ō', 'Ŏ', 'ŏ', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 'ŕ', 'Ŗ', 'ŗ', 'Ř', 'ř', 'Ś', 'ś', 'Ŝ', 'ŝ', 'Ş', 'ş', 'Š', 'š', 'Ţ', 'ţ', 'Ť', 'ť', 'Ŧ', 'ŧ', 'Ũ', 'ũ', 'Ū', 'ū', 'Ŭ', 'ŭ', 'Ů', 'ů', 'Ű', 'ű', 'Ų', 'ų', 'Ŵ', 'ŵ', 'Ŷ', 'ŷ', 'Ÿ', 'Ź', 'ź', 'Ż', 'ż', 'Ž', 'ž', 'ſ', 'ƒ', 'Ơ', 'ơ', 'Ư', 'ư', 'Ǎ', 'ǎ', 'Ǐ', 'ǐ', 'Ǒ', 'ǒ', 'Ǔ', 'ǔ', 'Ǖ', 'ǖ', 'Ǘ', 'ǘ', 'Ǚ', 'ǚ', 'Ǜ', 'ǜ', 'Ǻ', 'ǻ', 'Ǽ', 'ǽ', 'Ǿ', 'ǿ');
	$b = array('A', 'A', 'A', 'A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'U', 'Y', 's', 'a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'D', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'IJ', 'ij', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'l', 'l', 'N', 'n', 'N', 'n', 'N', 'n', 'n', 'O', 'o', 'O', 'o', 'O', 'o', 'OE', 'oe', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'S', 's', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Y', 'Z', 'z', 'Z', 'z', 'Z', 'z', 's', 'f', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'A', 'a', 'AE', 'ae', 'O', 'o');
	$text = str_replace($a, $b, $text);
	
	$text = preg_replace('~[^\pL\d]+~u', '-', $text);

	// transliterate
	$text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

	// remove unwanted characters
	$text = preg_replace('~[^-\w]+~', '', $text);

	// trim
	$text = trim($text, '-');

	// remove duplicate -
	$text = preg_replace('~-+~', '-', $text);

	// lowercase
	$text = strtolower($text);

	if (empty($text)) {
		return 'n-a';
	}

	return $text;
}

function current_page(){
	$request = preg_replace('/\?.*/', '', basename($_SERVER["REQUEST_URI"]));
	return $request;
}

function ayar($field){
	global $settingsStore;
	$result = $settingsStore->findById(1);
	return $result[$field];
}

function elements($datanames = []){
	global $datas;
	foreach($datanames as $datanamesVal){
	$datas[$datanamesVal] = $_POST[$datanamesVal];
	}
	return $datas;
}

function elementsP($datanames = []){
	global $datasP;
	foreach($datanames as $datanamesVal){
	$datasP[$datanamesVal] = $_POST[$datanamesVal];
	}
	return $datasP;
}

function query($identy,$where = '',$skip = '',$limit = ''){
	$query = $identy->createQueryBuilder();
	if($limit == '' and $skip == ''):
	if($where == ''):
	$datas = $query->orderBy(["_id" => "desc"])->getQuery()->fetch();
	else:
	$datas = $query->where($params)->orderBy(["_id" => "desc"])->getQuery()->fetch();
	endif;
	else:
	if($where == ''):
	$datas = $query->orderBy(["_id" => "desc"])->skip($skip)->limit($limit)->getQuery()->fetch();
	else:
	$datas = $query->where($params)->orderBy(["_id" => "desc"])->skip($skip)->limit($limit)->getQuery()->fetch();
	endif;
	endif;
	return $datas;
}

function uploadFile($ident,$path,$compressVal,$extvalid = null){
	global $allowedCompress;
	global $allowedExtensions;
	if (null === $extvalid) {
		$extvalid = $allowedExtensions;
	}
	if($_FILES[$ident]['name'] != "") {
	$image=$_FILES[$ident]['name']; 
	$expimage=explode('.',$image);
	$filetypeOut = array_pop($expimage);
	$filenameOut = implode('.', $expimage);
	if(in_array($filetypeOut,$extvalid)){
	$imagename=slug($filenameOut).'_'.time().'.'.$filetypeOut;
	$imagepath="../images/uploads/".$path."/".$imagename;
	move_uploaded_file($_FILES[$ident]["tmp_name"],$imagepath);
	$realpath = str_replace('../','',$imagepath);
	return $realpath;
	}
	}else{
	return '';
	}
}

function active($fileNames){
	if (in_array(basename($_SERVER["SCRIPT_FILENAME"]), $fileNames)) {
		return 'active';
	}else{
		return '';
	}
}

function show($fileNames){
	if (in_array(basename($_SERVER["SCRIPT_FILENAME"]), $fileNames)) {
		return 'show';
	}else{
		return '';
	}
}

function expanded($fileNames){
	if (in_array(basename($_SERVER["SCRIPT_FILENAME"]), $fileNames)) {
		return 'true';
	}else{
		return 'false';
	}
}

function post_redirect(){
	$base = basename($_SERVER["SCRIPT_FILENAME"]);
	$exp = explode('_', $base);
	$pop = '_'.array_pop($exp);
	$pop = str_replace('.php', '', $pop);
	$result = str_replace($pop,'_all',$base);
	return $result;
}

function updateFile($fileget,$ident,$path,$compressVal,$extvalid = null){
	global $allowedCompress;
	global $allowedExtensions;
	if (null === $extvalid) {
		$extvalid = $allowedExtensions;
	}
	if($_FILES[$ident]['name'] != "") {
	if(!empty($fileget)):
	chmod('../'.$fileget,0777);
	unlink('../'.$fileget);
	endif;
	$image=$_FILES[$ident]['name']; 
	$expimage=explode('.',$image);
	$filetypeOut = array_pop($expimage);
	$filenameOut = implode('.', $expimage);
	if(in_array($filetypeOut,$extvalid)){
	$imagename=slug($filenameOut).'_'.time().'.'.$filetypeOut;
	$imagepath="../images/uploads/".$path."/".$imagename;
	move_uploaded_file($_FILES[$ident]["tmp_name"],$imagepath);
	$realpath = str_replace('../','',$imagepath);
	return $realpath;
	}
	}
}

function rmData($identy,$filename = ""){
	if(isset($_GET['id'])){
	$datas = $identy->findById($_GET['id']);
	if(!empty($filename)):
	if(!empty($datas[$filename])):
	chmod('../'.$datas[$filename],0777);
	unlink('../'.$datas[$filename]);
	endif;
	endif;
	$identy->deleteById($_GET['id']);
	echo "<script type='text/javascript'>window.top.location='".current_page()."';</script>"; exit;
	}
}

function limiter($string, $word_limit) {
$string = strip_tags($string);
$words = explode(' ', strip_tags($string));
$return = trim(implode(' ', array_slice($words, 0, $word_limit)));
if(strlen($return) < strlen($string)){
$return .= '...';
}
return $return;
}

function randomizer($length = 10) {
return strtolower(substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length));
}

function dataSlug($input,$slug){
	$result = $input->findOneBy(["slug", "=", $slug]);
	return $result;
}
function dataOne($input,$value,$field = '_id'){
	$result = $input->findOneBy([$field, "=", $value]);
	return $result;
}

class Paginator{
	const NUM_PLACEHOLDER = '(:num)';

	protected $totalItems;
	protected $numPages;
	protected $itemsPerPage;
	protected $currentPage;
	protected $urlPattern;
	protected $maxPagesToShow = 10;
	protected $previousText = 'Previous';
	protected $nextText = 'Next';

	/**
	 * @param int $totalItems The total number of items.
	 * @param int $itemsPerPage The number of items per page.
	 * @param int $currentPage The current page number.
	 * @param string $urlPattern A URL for each page, with (:num) as a placeholder for the page number. Ex. '/foo/page/(:num)'
	 */
	public function __construct($totalItems, $itemsPerPage, $currentPage, $urlPattern = '')
	{
		$this->totalItems = $totalItems;
		$this->itemsPerPage = $itemsPerPage;
		$this->currentPage = $currentPage;
		$this->urlPattern = $urlPattern;

		$this->updateNumPages();
	}

	protected function updateNumPages()
	{
		$this->numPages = ($this->itemsPerPage == 0 ? 0 : (int) ceil($this->totalItems/$this->itemsPerPage));
	}

	/**
	 * @param int $maxPagesToShow
	 * @throws \InvalidArgumentException if $maxPagesToShow is less than 3.
	 */
	public function setMaxPagesToShow($maxPagesToShow)
	{
		if ($maxPagesToShow < 3) {
			throw new \InvalidArgumentException('maxPagesToShow cannot be less than 3.');
		}
		$this->maxPagesToShow = $maxPagesToShow;
	}

	/**
	 * @return int
	 */
	public function getMaxPagesToShow()
	{
		return $this->maxPagesToShow;
	}

	/**
	 * @param int $currentPage
	 */
	public function setCurrentPage($currentPage)
	{
		$this->currentPage = $currentPage;
	}

	/**
	 * @return int
	 */
	public function getCurrentPage()
	{
		return $this->currentPage;
	}

	/**
	 * @param int $itemsPerPage
	 */
	public function setItemsPerPage($itemsPerPage)
	{
		$this->itemsPerPage = $itemsPerPage;
		$this->updateNumPages();
	}

	/**
	 * @return int
	 */
	public function getItemsPerPage()
	{
		return $this->itemsPerPage;
	}

	/**
	 * @param int $totalItems
	 */
	public function setTotalItems($totalItems)
	{
		$this->totalItems = $totalItems;
		$this->updateNumPages();
	}

	/**
	 * @return int
	 */
	public function getTotalItems()
	{
		return $this->totalItems;
	}

	/**
	 * @return int
	 */
	public function getNumPages()
	{
		return $this->numPages;
	}

	/**
	 * @param string $urlPattern
	 */
	public function setUrlPattern($urlPattern)
	{
		$this->urlPattern = $urlPattern;
	}

	/**
	 * @return string
	 */
	public function getUrlPattern()
	{
		return $this->urlPattern;
	}

	/**
	 * @param int $pageNum
	 * @return string
	 */
	public function getPageUrl($pageNum)
	{
		return str_replace(self::NUM_PLACEHOLDER, $pageNum, $this->urlPattern);
	}

	public function getNextPage()
	{
		if ($this->currentPage < $this->numPages) {
			return $this->currentPage + 1;
		}

		return null;
	}

	public function getPrevPage()
	{
		if ($this->currentPage > 1) {
			return $this->currentPage - 1;
		}

		return null;
	}

	public function getNextUrl()
	{
		if (!$this->getNextPage()) {
			return null;
		}

		return $this->getPageUrl($this->getNextPage());
	}

	/**
	 * @return string|null
	 */
	public function getPrevUrl()
	{
		if (!$this->getPrevPage()) {
			return null;
		}

		return $this->getPageUrl($this->getPrevPage());
	}

	/**
	 * Get an array of paginated page data.
	 *
	 * Example:
	 * array(
	 *     array ('num' => 1,     'url' => '/example/page/1',  'isCurrent' => false),
	 *     array ('num' => '...', 'url' => NULL,               'isCurrent' => false),
	 *     array ('num' => 3,     'url' => '/example/page/3',  'isCurrent' => false),
	 *     array ('num' => 4,     'url' => '/example/page/4',  'isCurrent' => true ),
	 *     array ('num' => 5,     'url' => '/example/page/5',  'isCurrent' => false),
	 *     array ('num' => '...', 'url' => NULL,               'isCurrent' => false),
	 *     array ('num' => 10,    'url' => '/example/page/10', 'isCurrent' => false),
	 * )
	 *
	 * @return array
	 */
	public function getPages()
	{
		$pages = array();

		if ($this->numPages <= 1) {
			return array();
		}

		if ($this->numPages <= $this->maxPagesToShow) {
			for ($i = 1; $i <= $this->numPages; $i++) {
				$pages[] = $this->createPage($i, $i == $this->currentPage);
			}
		} else {

			// Determine the sliding range, centered around the current page.
			$numAdjacents = (int) floor(($this->maxPagesToShow - 3) / 2);

			if ($this->currentPage + $numAdjacents > $this->numPages) {
				$slidingStart = $this->numPages - $this->maxPagesToShow + 2;
			} else {
				$slidingStart = $this->currentPage - $numAdjacents;
			}
			if ($slidingStart < 2) $slidingStart = 2;

			$slidingEnd = $slidingStart + $this->maxPagesToShow - 3;
			if ($slidingEnd >= $this->numPages) $slidingEnd = $this->numPages - 1;

			// Build the list of pages.
			$pages[] = $this->createPage(1, $this->currentPage == 1);
			if ($slidingStart > 2) {
				$pages[] = $this->createPageEllipsis();
			}
			for ($i = $slidingStart; $i <= $slidingEnd; $i++) {
				$pages[] = $this->createPage($i, $i == $this->currentPage);
			}
			if ($slidingEnd < $this->numPages - 1) {
				$pages[] = $this->createPageEllipsis();
			}
			$pages[] = $this->createPage($this->numPages, $this->currentPage == $this->numPages);
		}


		return $pages;
	}


	/**
	 * Create a page data structure.
	 *
	 * @param int $pageNum
	 * @param bool $isCurrent
	 * @return Array
	 */
	protected function createPage($pageNum, $isCurrent = false)
	{
		return array(
			'num' => $pageNum,
			'url' => $this->getPageUrl($pageNum),
			'isCurrent' => $isCurrent,
		);
	}

	/**
	 * @return array
	 */
	protected function createPageEllipsis()
	{
		return array(
			'num' => '...',
			'url' => null,
			'isCurrent' => false,
		);
	}

	/**
	 * Render an HTML pagination control.
	 *
	 * @return string
	 */
	public function toHtml()
	{
		if ($this->numPages <= 1) {
			return '';
		}

		$html = '<ul class="pagination">';
		if ($this->getPrevUrl()) {
			$html .= '<li><a href="' . htmlspecialchars($this->getPrevUrl()) . '">&laquo; '. $this->previousText .'</a></li>';
		}

		foreach ($this->getPages() as $page) {
			if ($page['url']) {
				$html .= '<li' . ($page['isCurrent'] ? ' class="active"' : '') . '><a href="' . htmlspecialchars($page['url']) . '">' . htmlspecialchars($page['num']) . '</a></li>';
			} else {
				$html .= '<li class="disabled"><span>' . htmlspecialchars($page['num']) . '</span></li>';
			}
		}

		if ($this->getNextUrl()) {
			$html .= '<li><a href="' . htmlspecialchars($this->getNextUrl()) . '">'. $this->nextText .' &raquo;</a></li>';
		}
		$html .= '</ul>';

		return $html;
	}

	public function __toString()
	{
		return $this->toHtml();
	}

	public function getCurrentPageFirstItem()
	{
		$first = ($this->currentPage - 1) * $this->itemsPerPage + 1;

		if ($first > $this->totalItems) {
			return null;
		}

		return $first;
	}

	public function getCurrentPageLastItem()
	{
		$first = $this->getCurrentPageFirstItem();
		if ($first === null) {
			return null;
		}

		$last = $first + $this->itemsPerPage - 1;
		if ($last > $this->totalItems) {
			return $this->totalItems;
		}

		return $last;
	}

	public function setPreviousText($text)
	{
		$this->previousText = $text;
		return $this;
	}

	public function setNextText($text)
	{
		$this->nextText = $text;
		return $this;
	}
}

?>